/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.6.24 : Database - agus_slamet
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`agus_slamet` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `agus_slamet`;

/*Table structure for table `antrian` */

DROP TABLE IF EXISTS `antrian`;

CREATE TABLE `antrian` (
  `id_antrian` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP,
  `mahasiswa` int(11) DEFAULT NULL,
  `loket` int(11) DEFAULT NULL,
  `status_layanan` enum('belum','sudah','tunggu') NOT NULL DEFAULT 'belum',
  PRIMARY KEY (`id_antrian`),
  UNIQUE KEY `mahasiswa` (`mahasiswa`),
  KEY `loket` (`loket`),
  CONSTRAINT `fk_antrian_loket` FOREIGN KEY (`loket`) REFERENCES `loket` (`id_loket`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_antrian_mahasiswa` FOREIGN KEY (`mahasiswa`) REFERENCES `mahasiswa` (`nim`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `antrian` */

insert  into `antrian`(`id_antrian`,`tanggal`,`mahasiswa`,`loket`,`status_layanan`) values (1,'2015-06-24 12:27:21',7,3,'belum'),(2,'2015-06-24 12:28:27',4,2,'belum'),(3,'2015-06-24 15:34:57',2,1,'belum'),(4,'2015-06-24 15:43:23',5,4,'belum');

/*Table structure for table `loket` */

DROP TABLE IF EXISTS `loket`;

CREATE TABLE `loket` (
  `id_loket` int(11) NOT NULL AUTO_INCREMENT,
  `nama_loket` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id_loket`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `loket` */

insert  into `loket`(`id_loket`,`nama_loket`) values (1,'LOKET 1'),(2,'LOKET 2'),(3,'LOKET 3'),(4,'LOKET 4');

/*Table structure for table `mahasiswa` */

DROP TABLE IF EXISTS `mahasiswa`;

CREATE TABLE `mahasiswa` (
  `nim` int(11) NOT NULL AUTO_INCREMENT,
  `nama_mahasiswa` varchar(100) DEFAULT '',
  `alamat` varchar(100) DEFAULT '',
  `jurusan` enum('SI','MI','TK','TI') DEFAULT 'TI',
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nim`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `mahasiswa` */

insert  into `mahasiswa`(`nim`,`nama_mahasiswa`,`alamat`,`jurusan`,`username`,`password`) values (1,'maman','Jl. Wonsobo No 10','TI','maman','wijaya'),(2,'Rangga','Jl. Janti No 10','TI','rangga','rangga'),(3,'Milasari','Jl. Wates Km 10','TI','mila','sari'),(4,'Tintus','Jl. Wonosobo No 10','TI','tin','tus'),(5,'Bayu','Jl. Mahendra','TI','bayu','bayu'),(6,'Wana','Jl. Wanasaba','TK','wana','wana'),(7,'Boyolali','Jl. Jogja','MI','boyo','lali'),(8,'Wandi','Jl. Test','SI','wan','di'),(9,'Anci','Jl. Wahid','SI','an','ci'),(10,'Samuel','Jl. Wirobrajan','MI','sam','uel');

/*Table structure for table `petugas` */

DROP TABLE IF EXISTS `petugas`;

CREATE TABLE `petugas` (
  `id_petugas` int(11) NOT NULL AUTO_INCREMENT,
  `nama_petugas` varchar(100) DEFAULT '',
  `username` varchar(50) DEFAULT '',
  `password` varchar(50) DEFAULT '',
  `loket` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_petugas`),
  KEY `loket` (`loket`),
  CONSTRAINT `fk_petugas_loket` FOREIGN KEY (`loket`) REFERENCES `loket` (`id_loket`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `petugas` */

insert  into `petugas`(`id_petugas`,`nama_petugas`,`username`,`password`,`loket`) values (1,'Wahyu Pramuja','wahyu','pramuja',1),(2,'Rangga','anak','akakom',2),(3,'Wanda','wanda','cantik',3),(4,'Rani','mukerji','india',4);

/*Table structure for table `v_detail_loket` */

DROP TABLE IF EXISTS `v_detail_loket`;

/*!50001 DROP VIEW IF EXISTS `v_detail_loket` */;
/*!50001 DROP TABLE IF EXISTS `v_detail_loket` */;

/*!50001 CREATE TABLE  `v_detail_loket`(
 `id_loket` int(11) ,
 `nama_loket` varchar(10) ,
 `jumlah_antrian` bigint(21) 
)*/;

/*View structure for view v_detail_loket */

/*!50001 DROP TABLE IF EXISTS `v_detail_loket` */;
/*!50001 DROP VIEW IF EXISTS `v_detail_loket` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_detail_loket` AS (select `a`.`loket` AS `id_loket`,`l`.`nama_loket` AS `nama_loket`,(select count(`t`.`tanggal`) from `antrian` `t` where (`t`.`loket` = `a`.`loket`)) AS `jumlah_antrian` from (`antrian` `a` join `loket` `l`) where (`a`.`loket` = `l`.`id_loket`) group by `a`.`loket`) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
