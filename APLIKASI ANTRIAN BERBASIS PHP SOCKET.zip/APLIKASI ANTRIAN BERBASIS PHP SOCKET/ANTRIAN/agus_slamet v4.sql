-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2015 at 01:12 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `agus_slamet`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(11) NOT NULL,
  `username` char(50) NOT NULL,
  `password` char(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `antrian`
--

CREATE TABLE IF NOT EXISTS `antrian` (
  `id_antrian` int(11) NOT NULL,
  `tanggal` datetime DEFAULT CURRENT_TIMESTAMP,
  `mahasiswa` int(11) DEFAULT NULL,
  `loket` int(11) DEFAULT NULL,
  `status_layanan` enum('belum','sudah') DEFAULT 'belum'
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `antrian`
--

INSERT INTO `antrian` (`id_antrian`, `tanggal`, `mahasiswa`, `loket`, `status_layanan`) VALUES
(5, '2015-08-04 16:17:06', 1, 1, 'belum'),
(6, '2015-08-04 16:49:59', 5, 16, 'sudah'),
(7, '2015-08-04 17:12:31', 3, 16, 'belum'),
(8, '2015-08-04 17:20:57', 7, 21, 'belum');

-- --------------------------------------------------------

--
-- Table structure for table `loket`
--

CREATE TABLE IF NOT EXISTS `loket` (
  `id_loket` int(11) NOT NULL,
  `nama_loket` int(11) DEFAULT NULL,
  `bagian` enum('PMB','KEUANGAN','PENGAJARAN') NOT NULL DEFAULT 'PMB'
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loket`
--

INSERT INTO `loket` (`id_loket`, `nama_loket`, `bagian`) VALUES
(1, 1, 'PMB'),
(3, 2, 'PMB'),
(16, 1, 'PENGAJARAN'),
(17, 2, 'PENGAJARAN'),
(21, 1, 'KEUANGAN'),
(22, 2, 'KEUANGAN'),
(26, 3, 'PMB'),
(27, 3, 'PENGAJARAN'),
(28, 3, 'KEUANGAN');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE IF NOT EXISTS `mahasiswa` (
  `nim` int(11) NOT NULL,
  `nama_mahasiswa` varchar(100) DEFAULT '',
  `alamat` varchar(100) DEFAULT '',
  `jurusan` enum('SI','MI','TK','TI') DEFAULT 'TI',
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama_mahasiswa`, `alamat`, `jurusan`, `username`, `password`) VALUES
(1, 'maman', 'Jl. Wonsobo No 10', 'TI', 'maman', 'wijaya'),
(2, 'Rangga', 'Jl. Janti No 10', 'TI', 'rangga', 'rangga'),
(3, 'Milasari', 'Jl. Wates Km 10', 'TI', 'mila', 'sari'),
(4, 'Tintus', 'Jl. Wonosobo No 10', 'TI', 'tin', 'tus'),
(5, 'Bayu', 'Jl. Mahendra', 'TI', 'bayu', 'bayu'),
(6, 'Wana', 'Jl. Wanasaba', 'TK', 'wana', 'wana'),
(7, 'Boyolali', 'Jl. Jogja', 'MI', 'boyo', 'lali'),
(8, 'Wandi', 'Jl. Test', 'SI', 'wan', 'di'),
(9, 'Anci', 'Jl. Wahid', 'SI', 'an', 'ci'),
(10, 'Samuel', 'Jl. Wirobrajan', 'MI', 'sam', 'uel');

-- --------------------------------------------------------

--
-- Table structure for table `petugas`
--

CREATE TABLE IF NOT EXISTS `petugas` (
  `id_petugas` int(11) NOT NULL,
  `nama_petugas` varchar(100) DEFAULT '',
  `username` varchar(50) DEFAULT '',
  `password` varchar(50) DEFAULT '',
  `loket` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `petugas`
--

INSERT INTO `petugas` (`id_petugas`, `nama_petugas`, `username`, `password`, `loket`) VALUES
(6, 'pmb1', 'pmb1', 'pmb1', 1),
(7, 'pengajaran1', 'pengajaran1', 'pengajaran1', 16),
(8, 'keuangan1', 'keuangan1', 'keuangan1', 21),
(9, 'pmb2', 'pmb2', 'pmb2', 3),
(10, 'pengajaran2', 'pengajaran2', 'pengajaran2', 17),
(11, 'keuangan2', 'keuangan2', 'keuangan2', 22);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_detail_loket`
--
CREATE TABLE IF NOT EXISTS `v_detail_loket` (
`id_loket` int(11)
,`nama_loket` int(11)
,`bagian` enum('PMB','KEUANGAN','PENGAJARAN')
,`jumlah_antrian` bigint(21)
);

-- --------------------------------------------------------

--
-- Structure for view `v_detail_loket`
--
DROP TABLE IF EXISTS `v_detail_loket`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_detail_loket` AS select `l`.`id_loket` AS `id_loket`,`l`.`nama_loket` AS `nama_loket`,`l`.`bagian` AS `bagian`,(select count(`an`.`tanggal`) from `antrian` `an` where (`an`.`loket` = `l`.`id_loket`)) AS `jumlah_antrian` from `loket` `l`;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `antrian`
--
ALTER TABLE `antrian`
  ADD PRIMARY KEY (`id_antrian`), ADD KEY `mahasiswa` (`mahasiswa`), ADD KEY `loket` (`loket`);

--
-- Indexes for table `loket`
--
ALTER TABLE `loket`
  ADD PRIMARY KEY (`id_loket`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `petugas`
--
ALTER TABLE `petugas`
  ADD PRIMARY KEY (`id_petugas`), ADD KEY `loket` (`loket`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `antrian`
--
ALTER TABLE `antrian`
  MODIFY `id_antrian` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `loket`
--
ALTER TABLE `loket`
  MODIFY `id_loket` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `nim` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `petugas`
--
ALTER TABLE `petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `antrian`
--
ALTER TABLE `antrian`
ADD CONSTRAINT `fk_antrian_loket` FOREIGN KEY (`loket`) REFERENCES `loket` (`id_loket`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `fk_antrian_mhs` FOREIGN KEY (`mahasiswa`) REFERENCES `mahasiswa` (`nim`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `petugas`
--
ALTER TABLE `petugas`
ADD CONSTRAINT `fk_petugas_loket` FOREIGN KEY (`loket`) REFERENCES `loket` (`id_loket`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
