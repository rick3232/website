<?php
if(isset($_POST['login'])){
    include './koneksi.php';
    $user = $_POST['username'];
    $pass = $_POST['password'];
    $sql = "select * from admin where username='$user' AND password='$pass'";
    $query = mysql_query($sql);
    if(mysql_num_rows($query)>0){
        session_start();
        $_SESSION['operator']='TRUE';
        header("location:index.php");
    }else{
        ?>
        <script>
            alert("Gagal Login");
            window.location.href="index.php";
        </script>
        <?php        
    }
}else{
    header("location:index.php");
}
