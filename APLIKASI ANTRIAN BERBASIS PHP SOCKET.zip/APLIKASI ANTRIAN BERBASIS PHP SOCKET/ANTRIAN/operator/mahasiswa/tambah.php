<?php
    if(isset($_POST['tambah_mahasiswa'])){
        require_once("../koneksi.php");
        $nama_mahasiswa=$_POST['nama_mahasiswa'];
        $alamat = $_POST['alamat'];
        $jurusan = $_POST['jurusan'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $sql = "insert into mahasiswa(nama_mahasiswa,alamat,jurusan,username,password) values ('$nama_mahasiswa','$alamat','$jurusan','$username','$password')";
        mysql_query($sql);
        ?>
        <script>
            alert('Data Berhasil Di Tambahkan');
        </script>
        <?php
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">


    <!-- Mirrored from themes.startbootstrap.com/flex-admin-v1.2/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 Feb 2015 18:22:47 GMT -->
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Halaman Administrator</title>

        <!-- PACE LOAD BAR PLUGIN - This creates the subtle load bar effect at the top of the page. -->
        <!-- PACE LOAD BAR PLUGIN - This creates the subtle load bar effect at the top of the page. -->
        <link href="../assets/css/plugins/pace/pace.css" rel="stylesheet">
        <script src="../assets/js/plugins/pace/pace.js"></script>

        <!-- GLOBAL STYLES - Include these on every page. -->
        <link href="../assets/css/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="../assets/icons/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="../assets/jquery-ui.css" type="text/css" rel="stylesheet">
        <link href="../assets/css/plugins/bootstrap-tokenfield/tokenfield-typeahead.css" rel="stylesheet">
        <link href="../assets/css/plugins/bootstrap-tokenfield/bootstrap-tokenfield.css" rel="stylesheet">
        <!-- THEME STYLES - Include these on every page. -->
        <link href="../assets/css/style.css" rel="stylesheet">
        <link href="../assets/css/plugins.css" rel="stylesheet">

        <!-- THEME DEMO STYLES - Use these styles for reference if needed. Otherwise they can be deleted. -->
        <link href="../assets/css/demo.css" rel="stylesheet">

        <!--[if lt IE 9]>
        <script src="../assets/js/html5shiv.js"></script>
        <script src="../assets/js/respond.min.js"></script>
        <![endif]-->

    </head>

    <body>

    <div id="wrapper">

        <!-- begin TOP NAVIGATION -->
        <nav class="navbar-top" role="navigation">

            <!-- begin BRAND HEADING -->
            <div class="navbar-header">
                <div class="navbar-brand">
                    <span class="text-primary page-title">MENU ADMIN</span>
                </div>
            </div>
            <!-- end BRAND HEADING -->

            <div class="nav-top">
                <!-- begin MESSAGES/ALERTS/TASKS/USER ACTIONS DROPDOWNS -->
                <ul class="nav navbar-right">
                    <!-- begin USER ACTIONS DROPDOWN -->
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="fa fa-user"></i> <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
                            <li>
                                <a class="logout_open" href="../logout.php">
                                    <i class="fa fa-sign-out"></i> Logout
                                    <strong></strong>
                                </a>
                            </li>
                        </ul>
                        <!-- /.dropdown-menu -->
                    </li>
                    <!-- /.dropdown -->
                    <!-- end USER ACTIONS DROPDOWN -->

                </ul>
                <!-- /.nav -->
                <!-- end MESSAGES/ALERTS/TASKS/USER ACTIONS DROPDOWNS -->

            </div>
            <!-- /.nav-top -->
        </nav>
        <!-- /.navbar-top -->
        <!-- end TOP NAVIGATION -->

        <!-- begin SIDE NAVIGATION -->
        <nav class="navbar-side" role="navigation">
            <div class="navbar-collapse sidebar-collapse collapse">
                <ul id="side" class="nav navbar-nav side-nav">
                    <!-- begin DASHBOARD LINK -->
                    <li>
                        <a class="" href="../dashboard.php">
                            <i class="fa fa-dashboard"></i> Dashboard
                        </a>
                    </li>
                    <li class="panel">
                        <a href="javascript:;" data-parent="#side" data-toggle="collapse" class="accordion-toggle"
                           data-target="#mahasiswa">
                            <i class="fa fa-edit"></i> Mahasiswa <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="collapse nav in" id="mahasiswa">
                            <li>
                                <a class="active" href="tambah.php">
                                    <i class="fa fa-angle-double-right"></i> Tambah Mahasiswa
                                </a>
                            </li>
                            <li>
                                <a href="data.php">
                                    <i class="fa fa-angle-double-right"></i> Data Mahasiswa
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="panel">
                        <a href="javascript:;" data-parent="#side" data-toggle="collapse" class="accordion-toggle"
                           data-target="#petugas">
                            <i class="fa fa-edit"></i> Petugas <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="collapse nav" id="petugas">
                            <li>
                                <a href="../petugas/tambah.php">
                                    <i class="fa fa-angle-double-right"></i> Tambah Petugas
                                </a>
                            </li>
                            <li>
                                <a href="../petugas/data.php">
                                    <i class="fa fa-angle-double-right"></i> Data Petugas
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="panel">
                        <a href="javascript:;" data-parent="#side" data-toggle="collapse" class="accordion-toggle"
                           data-target="#loket">
                            <i class="fa fa-edit"></i> Loket <i class="fa fa-caret-down"></i>
                        </a>
                        <ul class="collapse nav" id="loket">
                            <li>
                                <a href="../loket/tambah.php">
                                    <i class="fa fa-angle-double-right"></i> Tambah Loket
                                </a>
                            </li>
                            <li>
                                <a href="../loket/data.php">
                                    <i class="fa fa-angle-double-right"></i> Data Loket
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.side-nav -->
            </div>
            <!-- /.navbar-collapse -->
        </nav>
        <!-- /.navbar-side -->
        <!-- end SIDE NAVIGATION -->

        <!-- begin MAIN PAGE CONTENT -->
        <div id="page-wrapper">

            <div class="page-content">
                <!-- begin PAGE TITLE ROW -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="page-title">
                            <ol class="breadcrumb">
                                <li><i class="fa fa-dashboard"></i> Mahasiswa</li>
                                <li class="active"> <a href="data.php">Tambah</a>
                                </li>
                            </ol>
                        </div>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <!-- end PAGE TITLE ROW -->

                <!-- FAQ Accordion -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="portlet portlet-default">
                            <div class="portlet-heading">
                                <div class="portlet-title">
                                    <h4>Tambah Mahasiswa</h4>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div id="basicFormExample" class="panel-collapse collapse in">
                                <div class="portlet-body">
                                    <form role="form" method="post" action="tambah.php">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Nama Mahasiswa</label>
                                            <input type="text" class="form-control" name="nama_mahasiswa" placeholder="Mr. Potato" required="">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Alamat</label>
                                            <input type="text" class="form-control" name="alamat" placeholder="Jl. Wates No 10" required="">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Jurusan</label>
                                            <select class="form-control" name="jurusan">
                                                <option value="TI">TI</option>
                                                <option value="SI">SI</option>
                                                <option value="MI">MI</option>
                                                <option value="TK">TK</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Username</label>
                                            <input type="text" class="form-control" name="username" placeholder="potato" required="">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Password</label>
                                            <input type="password" class="form-control" name="password" placeholder="Password" required="">
                                        </div>
                                        <button type="submit" class="btn btn-default" name="tambah_mahasiswa">Tambah</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.page-content -->

        </div>
        <!-- /#page-wrapper -->
        <!-- end MAIN PAGE CONTENT -->

    </div>
    <!-- /#wrapper -->
    <script src="../assets/js/plugins/popupoverlay/logout.js"></script>
    <!-- HISRC Retina Images -->
    <script src="../assets/js/plugins/hisrc/hisrc.js"></script>

    <!-- GLOBAL SCRIPTS -->
    <script src="../assets/jquery-2.1.1.js"></script>
    <script src="../assets/js/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="../assets/js/plugins/popupoverlay/jquery.popupoverlay.js"></script>
    <script src="../assets/js/plugins/popupoverlay/defaults.js"></script>
    <!-- PAGE LEVEL PLUGIN SCRIPTS -->
    <script src="../assets/js/plugins/bootstrap-tokenfield/bootstrap-tokenfield.min.js"></script>
    <script src="../assets/js/plugins/bootstrap-tokenfield/scrollspy.js"></script>
    <script src="../assets/js/plugins/bootstrap-tokenfield/affix.js"></script>
    <script src="../assets/js/plugins/bootstrap-tokenfield/typeahead.min.js"></script>
    <script src="../assets/js/plugins/bootstrap-maxlength/bootstrap-maxlength.js"></script>
    <script src="../assets/js/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
    <script src="../assets/js/plugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>
    <!-- THEME SCRIPTS -->
    <script src="../assets/js/flex.js"></script>
    <script src="../assets/js/demo/advanced-form-demo.js"></script>
    </body>
    </html>