<?php 

require_once("../koneksi.php");
$id_loket = $_POST['id_loket'];
$sql = "delete from loket where id_loket=$id_loket";
if(mysql_query($sql)){
    echo "Data berhasil di hapus";
}else{
    echo "Data gagal di hapus";
}