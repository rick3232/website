<?php
/**
 * Created by PhpStorm.
 * User: Dhandy
 * Date: 6/9/15
 * Time: 1:10 AM
 */ 
session_start();
session_unset("operator");
header("location:index.php");