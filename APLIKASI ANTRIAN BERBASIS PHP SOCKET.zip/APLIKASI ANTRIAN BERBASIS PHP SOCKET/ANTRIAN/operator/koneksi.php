<?php
/**
 * Created by PhpStorm.
 * User: Dhandy
 * Date: 6/9/15
 * Time: 1:28 AM
 */
$host = "localhost";
$user = "root";
$pass = "";
$db = "agus_slamet";
mysql_connect($host,$user,$pass);
mysql_select_db($db);
