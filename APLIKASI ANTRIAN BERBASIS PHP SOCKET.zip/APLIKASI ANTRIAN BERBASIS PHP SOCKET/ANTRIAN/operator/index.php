<?php 
session_start();
if(isset($_SESSION['operator'])=='TRUE'){
    include './dashboard.php';
}else{
    include './login.php';
}

