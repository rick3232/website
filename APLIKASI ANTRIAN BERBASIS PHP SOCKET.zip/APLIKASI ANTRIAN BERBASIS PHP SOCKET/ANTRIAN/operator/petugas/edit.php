<?php
if(isset($_GET['id_petugas']) && $_GET['id_petugas']!=""){
    require_once("../koneksi.php");
    $id_petugas = $_GET['id_petugas'];
    $sql = "select * from petugas where id_petugas=$id_petugas";
    $query = mysql_query($sql);
    if(mysql_num_rows($query)>0){
        $data_petugas = mysql_fetch_row($query);
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>

            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="description" content="">
            <meta name="author" content="">

            <title>Halaman Administrator</title>

            <!-- PACE LOAD BAR PLUGIN - This creates the subtle load bar effect at the top of the page. -->
            <!-- PACE LOAD BAR PLUGIN - This creates the subtle load bar effect at the top of the page. -->
            <link href="../assets/css/plugins/pace/pace.css" rel="stylesheet">
            <script src="../assets/js/plugins/pace/pace.js"></script>

            <!-- GLOBAL STYLES - Include these on every page. -->
            <link href="../assets/css/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
            <link href="../assets/icons/font-awesome/css/font-awesome.min.css" rel="stylesheet">
            <link href="../assets/jquery-ui.css" type="text/css" rel="stylesheet">
            <link href="../assets/css/plugins/bootstrap-tokenfield/tokenfield-typeahead.css" rel="stylesheet">
            <link href="../assets/css/plugins/bootstrap-tokenfield/bootstrap-tokenfield.css" rel="stylesheet">
            <!-- THEME STYLES - Include these on every page. -->
            <link href="../assets/css/style.css" rel="stylesheet">
            <link href="../assets/css/plugins.css" rel="stylesheet">

            <!-- THEME DEMO STYLES - Use these styles for reference if needed. Otherwise they can be deleted. -->
            <link href="../assets/css/demo.css" rel="stylesheet">

            <!--[if lt IE 9]>
            <script src="../assets/js/html5shiv.js"></script>
            <script src="../assets/js/respond.min.js"></script>
            <![endif]-->

        </head>

        <body>

        <div id="wrapper">

            <!-- begin TOP NAVIGATION -->
            <nav class="navbar-top" role="navigation">

                <!-- begin BRAND HEADING -->
                <div class="navbar-header">
                    <div class="navbar-brand">
                        <span class="text-primary page-title">MENU ADMIN</span>
                    </div>
                </div>
                <!-- end BRAND HEADING -->

                <div class="nav-top">
                    <!-- begin MESSAGES/ALERTS/TASKS/USER ACTIONS DROPDOWNS -->
                    <ul class="nav navbar-right">
                        <!-- begin USER ACTIONS DROPDOWN -->
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-user"></i> <i class="fa fa-caret-down"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li>
                                    <a class="logout_open" href="../logout.php">
                                        <i class="fa fa-sign-out"></i> Logout
                                        <strong></strong>
                                    </a>
                                </li>
                            </ul>
                            <!-- /.dropdown-menu -->
                        </li>
                        <!-- /.dropdown -->
                        <!-- end USER ACTIONS DROPDOWN -->

                    </ul>
                    <!-- /.nav -->
                    <!-- end MESSAGES/ALERTS/TASKS/USER ACTIONS DROPDOWNS -->

                </div>
                <!-- /.nav-top -->
            </nav>
            <!-- /.navbar-top -->
            <!-- end TOP NAVIGATION -->

            <!-- begin SIDE NAVIGATION -->
            <nav class="navbar-side" role="navigation">
                <div class="navbar-collapse sidebar-collapse collapse">
                    <ul id="side" class="nav navbar-nav side-nav">
                        <!-- begin DASHBOARD LINK -->
                        <li>
                            <a class="" href="../dashboard.php">
                                <i class="fa fa-dashboard"></i> Dashboard
                            </a>
                        </li>
                        <li class="panel">
                            <a href="javascript:;" data-parent="#side" data-toggle="collapse" class="accordion-toggle"
                               data-target="#mahasiswa">
                                <i class="fa fa-edit"></i> Mahasiswa <i class="fa fa-caret-down"></i>
                            </a>
                            <ul class="collapse nav" id="mahasiswa">
                                <li>
                                    <a href="../mahasiswa/tambah.php">
                                        <i class="fa fa-angle-double-right"></i> Tambah Mahasiswa
                                    </a>
                                </li>
                                <li>
                                    <a href="../mahasiswa/data.php">
                                        <i class="fa fa-angle-double-right"></i> Data Mahasiswa
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="panel">
                            <a href="javascript:;" data-parent="#side" data-toggle="collapse" class="accordion-toggle"
                               data-target="#petugas">
                                <i class="fa fa-edit"></i> Petugas <i class="fa fa-caret-down"></i>
                            </a>
                            <ul class="collapse nav in" id="petugas">
                                <li>
                                    <a href="tambah.php">
                                        <i class="fa fa-angle-double-right"></i> Tambah Petugas
                                    </a>
                                </li>
                                <li>
                                    <a class="active" href="data.php">
                                        <i class="fa fa-angle-double-right"></i> Data Petugas
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="panel">
                            <a href="javascript:;" data-parent="#side" data-toggle="collapse" class="accordion-toggle"
                               data-target="#loket">
                                <i class="fa fa-edit"></i> Loket <i class="fa fa-caret-down"></i>
                            </a>
                            <ul class="collapse nav" id="loket">
                                <li>
                                    <a href="../loket/tambah.php">
                                        <i class="fa fa-angle-double-right"></i> Tambah Loket
                                    </a>
                                </li>
                                <li>
                                    <a href="../loket/data.php">
                                        <i class="fa fa-angle-double-right"></i> Data Loket
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                    <!-- /.side-nav -->
                </div>
                <!-- /.navbar-collapse -->
            </nav>
            <!-- /.navbar-side -->
            <!-- end SIDE NAVIGATION -->

            <!-- begin MAIN PAGE CONTENT -->
            <div id="page-wrapper">

                <div class="page-content">
                    <!-- begin PAGE TITLE ROW -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="page-title">
                                <ol class="breadcrumb">
                                    <li><i class="fa fa-dashboard"></i> Petugas</li>
                                    <li class="active"> <a href="data.php">Edit</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <!-- end PAGE TITLE ROW -->

                    <!-- FAQ Accordion -->
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="portlet portlet-default">
                                <div class="portlet-heading">
                                    <div class="portlet-title">
                                        <h4>Edit Data Petugas</h4>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div id="basicFormExample" class="panel-collapse collapse in">
                                    <div class="portlet-body">
                                        <form role="form" method="post" action="edit.php">
                                            <input type="hidden" value="<?php echo $data_petugas[0];?>" name="id_petugas">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Nama Petugas</label>
                                                <input type="text" class="form-control" name="nama_petugas" placeholder="Mr. Potato" value="<?php echo $data_petugas[1];?>" required="">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Username</label>
                                                <input type="text" class="form-control" name="username" placeholder="potato" value="<?php echo $data_petugas[2];?>" required="">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputPassword1">Password</label>
                                                <input type="password" class="form-control" name="password" placeholder="Password" value="<?php echo $data_petugas[3];?>" required="">
                                            </div>
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Loket</label>
                                                <select class="form-control" name="loket">
                                                    <?php
                                                    $sql_lkt  = "select * from loket";
                                                    $query_lkt = mysql_query($sql_lkt);
                                                    while($row=mysql_fetch_array($query_lkt)){
                                                        if($row[0]==$data_petugas[4]){
                                                            ?>
                                                            <option value="<?php echo $row[0];?>" selected><?php echo $row[1];?></option>
                                                        <?php
                                                        }else{
                                                            ?>
                                                            <option value="<?php echo $row[0];?>"><?php echo $row[1];?></option>
                                                        <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <button type="submit" class="btn btn-default" name="update_petugas">Update</button>
                                            <a href="data.php" class="btn btn-primary">Batal</a>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.page-content -->

            </div>
            <!-- /#page-wrapper -->
            <!-- end MAIN PAGE CONTENT -->

        </div>
        <!-- /#wrapper -->
        <script src="../assets/js/plugins/popupoverlay/logout.js"></script>
        <!-- HISRC Retina Images -->
        <script src="../assets/js/plugins/hisrc/hisrc.js"></script>

        <!-- GLOBAL SCRIPTS -->
        <script src="../assets/jquery-2.1.1.js"></script>
        <script src="../assets/js/plugins/bootstrap/bootstrap.min.js"></script>
        <script src="../assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
        <script src="../assets/js/plugins/popupoverlay/jquery.popupoverlay.js"></script>
        <script src="../assets/js/plugins/popupoverlay/defaults.js"></script>
        <!-- PAGE LEVEL PLUGIN SCRIPTS -->
        <script src="../assets/js/plugins/bootstrap-tokenfield/bootstrap-tokenfield.min.js"></script>
        <script src="../assets/js/plugins/bootstrap-tokenfield/scrollspy.js"></script>
        <script src="../assets/js/plugins/bootstrap-tokenfield/affix.js"></script>
        <script src="../assets/js/plugins/bootstrap-tokenfield/typeahead.min.js"></script>
        <script src="../assets/js/plugins/bootstrap-maxlength/bootstrap-maxlength.js"></script>
        <script src="../assets/js/plugins/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
        <script src="../assets/js/plugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>
        <!-- THEME SCRIPTS -->
        <script src="../assets/js/flex.js"></script>
        <script src="../assets/js/demo/advanced-form-demo.js"></script>
        <script>
            function batal(){
                window.location.href="data.php";
            }
        </script>
        </body>
        </html>
    <?php
    }else{
        header("location:data.php");
    }
}else if(isset($_POST['update_petugas'])){
    require_once("../koneksi.php");
    $id_petugas = $_POST['id_petugas'];
    $nama_petugas=$_POST['nama_petugas'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $loket = $_POST['loket'];
    $sql = "update petugas set nama_petugas='$nama_petugas', loket='$loket', username='$username', password='$password' where id_petugas=$id_petugas";
    mysql_query($sql);
    ?>
    <script>
        alert("Data Berhasil Di Update");
        window.location.href="data.php";
    </script>
    <?php
}else{
    header("location:data.php");
}
