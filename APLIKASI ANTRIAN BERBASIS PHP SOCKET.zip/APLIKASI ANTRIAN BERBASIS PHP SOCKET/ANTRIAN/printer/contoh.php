<?php
date_default_timezone_set('Asia/Jakarta');
$printer = '\\\\192.168.182.105\\ZJ-5870(copy of 2)';

$handle = printer_open($printer);
printer_start_doc($handle, "My Document");
printer_start_page($handle);

$font = printer_create_font("Arial", 40, 40, PRINTER_FW_MEDIUM, false, false, false, 0);
printer_select_font($handle, $font);
printer_draw_text($handle, "   NO 1", 0, 0);
printer_draw_text($handle, "LOKET 1", 0, 50);
printer_delete_font($font);

$font = printer_create_font("Arial", 0, 0, PRINTER_FW_MEDIUM, false, false, false, 0);
printer_select_font($handle, $font);
printer_draw_text($handle, date("D M d, Y G:i a"), 0, 100);
printer_delete_font($font);

printer_end_page($handle);
printer_end_doc($handle);
printer_close($handle);
?>