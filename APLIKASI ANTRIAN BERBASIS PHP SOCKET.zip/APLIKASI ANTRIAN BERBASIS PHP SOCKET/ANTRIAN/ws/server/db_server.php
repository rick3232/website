<?php
/**
 * Created by PhpStorm.
 * User: Dhandy
 * Date: 6/1/15
 * Time: 9:24 PM
 */
class db_server{
    private $host = "localhost";
    private $user = "root";
    private $pass = "";
    private $db = "agus_slamet";
    function db_server(){
        mysql_connect($this->host,$this->user,$this->pass);
        mysql_select_db($this->db);
    }
    function login($type,$loket,$username,$password){
        if($type=='petugas'){
            $sql = "select * from petugas_loket where username='".$username."' and password='".$password."' and loket=".$loket."";
            $query = mysql_query($sql);
            $rows = mysql_num_rows($query);
            return $rows;
        }else if($type=='mahasiswa'){
            $sql = "select * from mahasiswa where username='".$username."' and password='".$password."'";
            $query = mysql_query($sql);
            $rows = mysql_num_rows($query);
            return $rows;
        }else{
            return 0;
        }
    }
    function getAccountLogin($loket,$username,$password){
        $sql = "select nama_petugas from petugas_loket where username='".$username."' and password='".$password."' and loket=".$loket."";
        $query = mysql_query($sql);
        $data = mysql_fetch_row($query);
        return $data[0];
    }
    function getAllLoket(){
        $sql = "select * from loket";
        $query = mysql_query($sql);
        $data = [];
        while($row=mysql_fetch_assoc($query)){
            array_push($data,[
                'id_loket'=>$row['id_loket'],
                'nama_loket'=>$row['nama_loket']
            ]);
        }
        return $data;
    }
}