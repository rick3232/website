
<?php
// Run from command prompt > php -q ws_server.php
include "phpwebsocket.php";
include "db_server.php";
$server_ip="localhost";  //what is the IP of your server

// Extended basic WebSocket as ws_server
class ws_server extends phpWebSocket{
   private $db;
  //Overridden process function from websocket.class.php
  function process($user,$msg){
      $this->db = new Db_Server();
      $data = json_decode($msg,true);
      extract($data , EXTR_PREFIX_SAME, "wddx");
      if($id=="petugas"){
          if($type=="login"){
              if($this->db->login($id,$loket,$username,$password)>0){
                  $nama_petugas = $this->db->getAccountLogin($loket,$username,$password);
                  echo "NAMA PETUIGAS : ".$nama_petugas;
                  $data = array(
                      "id"=>"petugas",
                      "type"=>"login",
                      "nama_petugas"=>$nama_petugas,
                      "response"=>"true"
                  );
                  $this->send($user->socket,json_encode($data));
              }else{
                  $data = array(
                      "id"=>"petugas",
                      "type"=>"login",
                      "response"=>"failed"
                  );
                  $this->send($user->socket,json_encode($data));
              }
          }else if($type=="request_loket"){
              $data = array(
                  "id"=>"petugas",
                  "type"=>"response_loket",
                  "response"=>$this->db->getAllLoket()
              );
              $this->send($user->socket,json_encode($data));
          }
      }
  }
}  //end class

$master = new ws_server($server_ip,4444);
