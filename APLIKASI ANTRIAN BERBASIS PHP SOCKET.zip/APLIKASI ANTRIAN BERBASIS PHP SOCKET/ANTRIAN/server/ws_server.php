
<?php
// Run from command prompt > php -q ws_server.php
include "phpwebsocket.php";
include "db_server.php";
$server_ip="127.0.0.1";  //ip server ku  atau ip yg jd monitor

// Extended basic WebSocket as ws_server
class ws_server extends phpWebSocket{
   private $db;
  //Overridden process function from websocket.class.php
  function process($user,$msg){
      $this->db = new Db_Server();
      $data = json_decode($msg,true);
      extract($data , EXTR_PREFIX_SAME, "wddx");
      if($type=="request_login"){
          if($by=='mahasiswa'){
              $loket = "";
              if($this->db->login($by,$loket,$username,$password)>0){
                  $data_mahasiswa = $this->db->getAccountLogin($by,$loket,$username,$password);
                  $data = array(
                      "type"=>"response_login",
                      "id_mahasiswa"=>$data_mahasiswa[0],
                      "nama_mahasiswa"=>$data_mahasiswa[1],
                      "response"=>"true"
                  );
                  $user->type="mahasiswa";
                  $user->id_mahasiswa=$data_mahasiswa[0];
                  $this->send($user->socket,json_encode($data));
              }else{
                  $data = array(
                      "type"=>"response_login",
                      "response"=>"false"
                  );
                  $this->send($user->socket,json_encode($data));
              }
          }else if($by=='petugas'){
              if($this->db->login($by,$loket,$username,$password)>0){
                  $data_petugas = $this->db->getAccountLogin($by,$loket,$username,$password);
                  $data = array(
                      "type"=>"response_login",
                      "id_petugas"=>$data_petugas[0],
                      "nama_petugas"=>$data_petugas[1],
                      "loket"=>$loket,
                      "nama_loket"=>$this->db->getNamaLoket($loket),
                      "bagian"=>$this->db->getNamaBagian($loket),
                      "response"=>"true"
                  );
                  $user->type="petugas";
                  $user->loket="$loket";
                  $this->send($user->socket,json_encode($data));
              }else{
                  $data = array(
                      "type"=>"response_login",
                      "response"=>"false"
                  );
                  $this->send($user->socket,json_encode($data));
              }
          }
      }else if($type=="request_body"){
          if($by=='mahasiswa'){
              $data = array(
                  "type"=>"response_body",
                  "loket"=>$this->db->getAllLoket(),
                  "detail_loket"=>$this->db->getDetailLoket(),
                  "no_loket"=>$this->db->getLoketMahasiswa($mahasiswa),
                  "bagian"=>$this->db->getBagian($mahasiswa),
                  "no_antrian"=>$this->db->getNoAntrian($mahasiswa)
              );
              $this->send($user->socket,json_encode($data));
          }
      }else if($type=="request_loket"){
          $data = array(
              "type"=>"response_loket",
              "response"=>$this->db->getAllLoket()
          );
          $this->send($user->socket,json_encode($data));
      }else if($type=="request_first_antrian"){
          $data = array(
              "type"=>"response_first_antrian",
              "jumlah_antrian"=>$this->db->getJumlahAntrian($loket),
              "first_antrian"=>$this->db->getFirstAntrian($loket)
          );
          $this->send($user->socket,json_encode($data));
      }else if($type=="request_next_antrian"){
          $data = array(
              "type"=>"response_next_antrian",
              "loket"=>$loket,
              "antrian"=>$this->db->getNextAntrian($loket,$start)
          );
          $data_refresh = array(
              "type"=>"refresh_loket",
              "detail_loket"=>$this->db->getDetailLoket(),
          );
          foreach($this->users as $us){
              if($us->type=="petugas"){
                  $this->send($us->socket,json_encode($data));
              }else{
                  $this->send($us->socket,json_encode($data_refresh));
              }
          }
      }else if($type=="request_call"){
          $data_call= array(
              "type"=>"response_call",
              "antrian"=>$antrian,
              "loket"=>$this->db->getNamaLoket($loket),
              "bagian"=>$this->db->getNamaBagian($loket)
          );
          foreach($this->users as $us){
              if($us->type!="petugas" && $us->type!="mahasiswa"){
                  $this->send($us->socket,json_encode($data_call));
              }
          }
      }else if($type=="request_monitor"){
          $data = array(
              "type"=>"refresh_loket",
              "detail_loket"=>$this->db->getDetailLoket(),
          );
          $this->send($user->socket,json_encode($data));
      }else if($type=="request_no_antrian"){
          if($by=='mahasiswa'){
              $this->db->setNoAntrian($mahasiswa,$loket);
              $data = array(
                  "type"=>"response_no_antrian"
              );
              foreach($this->users as $u){
                 if($u->type=="mahasiswa"){
                     $this->send($u->socket,json_encode($data));
                 }else if($u->type=="petugas"){
                     if($u->loket==$loket){
                         $data_petugas = array(
                             "type"=>"response_first_antrian",
                             "loket"=>$loket,
                             "jumlah_antrian"=>$this->db->getJumlahAntrian($loket),
                             "first_antrian"=>$this->db->getFirstAntrian($loket)
                         );
                         $this->send($u->socket,json_encode($data_petugas));
                     }
                 }else{
                     $data_monitor = array(
                         "type"=>"refresh_loket",
                         "detail_loket"=>$this->db->getDetailLoket(),
                     );                     
                     $this->send($u->socket,json_encode($data_monitor));
                 }
              }
          }
      }else if($type=="request_cetak"){
          $this->cetak($no_antrian,$loket);
          $data = array(
              "type"=>"response_cetak",
              "status"=>"OK"
          );
          $this->send($user->socket,json_encode($data));
      }
  }

  function cetak($no,$loket){
    date_default_timezone_set('Asia/Jakarta');
    $printer = '\\\\192.168.182.105\\ZJ-5870(copy of 2)';

    $handle = printer_open($printer);
    printer_start_doc($handle, "My Document");
    printer_start_page($handle);

    $font = printer_create_font("Arial", 40, 40, PRINTER_FW_MEDIUM, false, false, false, 0);
    printer_select_font($handle, $font);
    printer_draw_text($handle, "   NO ".$no, 0, 0);
    printer_draw_text($handle, " LOKET ".$loket, 0, 50);
    printer_delete_font($font);

    $font = printer_create_font("Arial", 0, 0, PRINTER_FW_MEDIUM, false, false, false, 0);
    printer_select_font($handle, $font);
    printer_draw_text($handle, date("D M d, Y G:i a"), 0, 100);
    printer_delete_font($font);

    printer_end_page($handle);
    printer_end_doc($handle);
    printer_close($handle);
  }
}  //end class

$master = new ws_server($server_ip,12345);
