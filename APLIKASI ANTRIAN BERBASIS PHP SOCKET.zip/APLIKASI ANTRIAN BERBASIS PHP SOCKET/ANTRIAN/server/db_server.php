<?php

/**
 * Created by PhpStorm.
 * User: Dhandy
 * Date: 6/1/15
 * Time: 9:24 PM
 */
class db_server {

    private $host = "localhost";
    private $user = "root";
    private $pass = "";
    private $db = "agus_slamet";

    function db_server() {
        mysql_connect($this->host, $this->user, $this->pass);
        mysql_select_db($this->db);
    }

    function login($by = "", $loket = "", $username = "", $password = "") {
        $sql = "";
        if ($by == 'petugas') {
            $sql = "select * from petugas where username='" . $username . "' and password='" . $password . "' and loket='" . $loket . "'";
        } else if ($by == 'mahasiswa') {
            $sql = "select * from mahasiswa where username='" . $username . "' and password='" . $password . "'";
        }
        $query = mysql_query($sql);
        $rows = mysql_num_rows($query);
        return $rows;
    }

    function getAccountLogin($by = "", $loket = "", $username = "", $password = "") {
        $sql = "";
        if ($by == 'petugas') {
            $sql = "select * from petugas where username='" . $username . "' and password='" . $password . "' and loket='" . $loket . "'";
        } else if ($by == 'mahasiswa') {
            $sql = "select * from mahasiswa where username='" . $username . "' and password='" . $password . "'";
        }
        $query = mysql_query($sql);
        $data = mysql_fetch_row($query);
        return $data;
    }

    function getNoAntrian($mahasiswa = "") {
        $sql = "SELECT * FROM antrian where status_layanan='belum' ORDER BY tanggal ASC";
        $query = mysql_query($sql);
        $data = null;
        while ($row = mysql_fetch_array($query)) {
            if ($row[2] == $mahasiswa) {
                $sql1 = "SELECT * FROM antrian where loket=" . $row[3] . " ORDER BY tanggal ASC";
                $query1 = mysql_query($sql1);
                $i = 0;
                while ($rows = mysql_fetch_array($query1)) {
                    $i++;
                    if ($rows[2] == $mahasiswa and $rows[4]=='belum') {
                        $data = $i;
                        break;
                    }
                }
                break;
            }
        }
        return $data;
    }

    function getLoketMahasiswa($mahasiswa = "") {
        $sql = "SELECT l.nama_loket FROM loket l,antrian a where l.id_loket=a.loket and a.mahasiswa=$mahasiswa and a.status_layanan='belum'";
        $query = mysql_query($sql);
        $data = mysql_fetch_row($query);
        return $data[0];
    }
    function getBagian($mahasiswa = "") {
        $sql = "SELECT l.bagian FROM loket l,antrian a where l.id_loket=a.loket and a.mahasiswa=$mahasiswa and a.status_layanan='belum'";
        $query = mysql_query($sql);
        $data = mysql_fetch_row($query);
        return $data[0];
    }
    function getNamaBagian($loket = "") {
        $sql = "SELECT bagian from loket where id_loket=$loket";
        $query = mysql_query($sql);
        $data = mysql_fetch_row($query);
        return $data[0];
    }
    function getNamaLoket($loket=""){
        $sql = "SELECT nama_loket from loket where id_loket=$loket";
        $query = mysql_query($sql);
        $data = mysql_fetch_row($query);
        return $data[0];
    }

    function setNoAntrian($mahasiswa, $loket) {
        $sql = "insert into antrian(mahasiswa,loket) values($mahasiswa,$loket)";
        mysql_query($sql);
    }

    function getDetailLoket() {
        $sql = "select * from v_detail_loket";
        $query = mysql_query($sql);
        $data = [];
        while ($row = mysql_fetch_assoc($query)) {
            $i = 0;
            $tunggu = 0;
            $query1 = mysql_query("SELECT * FROM antrian WHERE loket=" . $row['id_loket'] . " ORDER BY tanggal ASC;");
            while ($rs = mysql_fetch_assoc($query1)) {
                $i++;
                if ($rs['status_layanan'] == 'belum') {
                    $tunggu = $i;
                    break;
                }
            }
            array_push($data, [
                'id_loket' => $row['id_loket'],
                'nama_loket' => $row['nama_loket'],
                'bagian' => $row['bagian'],
                'jumlah_antrian' => $row['jumlah_antrian'],
                'sedang_antri' => $tunggu
            ]);
        }
        return $data;
    }

    function getFirstAntrian($loket = "") {
        $sql = "select status_layanan from antrian where loket=" . $loket . " ORDER BY tanggal asc";
        $query = mysql_query($sql);
        $i = 0;
        while ($row = mysql_fetch_array($query)) {
            $i++;
            if ($row['status_layanan'] == 'belum') {
                break;
            }
        }
        return $i;
    }

    function getNextAntrian($loket = "", $start) {
        $this->updateAntrian($loket, $start);
        $sql = "select status_layanan from antrian where loket=" . $loket . " ORDER BY tanggal asc";
        $query = mysql_query($sql);
        $i = $start;
        while ($row = mysql_fetch_array($query)) {
            if ($row['status_layanan'] == 'belum') {
                $i++;
                break;
            }
        }
        return $i;
    }

    function updateAntrian($loket, $no) {
        $sql = "select * from antrian where loket=" . $loket . " ORDER BY tanggal asc";
        $query = mysql_query($sql);
        $i = 1;
        while ($row = mysql_fetch_array($query)) {
            $sql1 = "update antrian set status_layanan='sudah' where id_antrian=" . $row[0] . "";
            mysql_query($sql1);
            if ($i == $no) {
                break;
            }
            $i++;
        }
    }

    function getJumlahAntrian($loket = "") {
        $sql = "select count(tanggal) from antrian where loket=" . $loket . "";
        $query = mysql_query($sql);
        $data = mysql_fetch_row($query);
        return $data[0];
    }

    function getAllLoket() {
        $sql = "select * from loket";
        $query = mysql_query($sql);
        $data = [];
        while ($row = mysql_fetch_assoc($query)) {
            array_push($data, [
                'id_loket' => $row['id_loket'],
                'nama_loket' => $row['nama_loket'],
                'bagian' => $row['bagian'],
            ]);
        }
        return $data;
    }

}
