<!DOCTYPE html>
<html>
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>APP ANTRIAN</title>
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="../assets/css/plugins/chosen/chosen.css" rel="stylesheet">
        <link href="../assets/css/animate.css" rel="stylesheet">
        <link href="../assets/css/style.css" rel="stylesheet">

    </head>

    <body class="gray-bg" onload="connect();">
        <div id="content">

        </div>

    </body>
    <!-- Mainly scripts -->
    <script src="../assets/js/jquery-2.1.1.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/chosen/chosen.jquery.js"></script>
    <script type="text/javascript">
        var socket;
        var url = null;
        var host = "127.0.0.1";//ip localhost atau ip server
        var port = "12345";
        var path = null;
        function connect()
        {
            host = "ws://" + host + ":" + port + "/agus_slamet/server/ws_server.php";
            url = host;
            try {
                socket = new WebSocket(host);
                socket.onopen = function (msg) {
                    $.ajax({
                        url: "main.php"
                    }).done(function (data) { // data what is sent back by the php page
                        $('#content').html(data); // display data
                        request_body();
                    });
                };
                socket.onmessage = function (msg) {
                    var response = JSON.parse(msg.data);
                    var i = 0;
                    if (response.type == "refresh_loket") {
                        var JSONObject = response.detail_loket;
                        var peopleHTML = "";
                        for (var key in JSONObject) {
                            if (JSONObject.hasOwnProperty(key)) {
                                peopleHTML += "<div class='col-md-2'>";
                                peopleHTML += "<div class='ibox float-e-margins'>";
                                peopleHTML += "<div class='ibox-title'>";
                                peopleHTML += "<h5 class='pull-left'>LOKET " + JSONObject[key]['nama_loket'] + "</h5>";
                                peopleHTML += "<h5 class='pull-right'>" + JSONObject[key]['bagian'] + "</h5>";
                                peopleHTML += "</div>";
                                peopleHTML += "<div class='ibox-content'>";
                                peopleHTML += "<div class='row'>";
                                peopleHTML += "<div class='col-xs-6'>";
                                peopleHTML += "<small class='stats-label'>Jumlah Antrian</small>";
                                peopleHTML += "<h4>" + JSONObject[key]['jumlah_antrian'] + "</h4>";
                                peopleHTML += "</div>";
                                peopleHTML += "<div class='col-xs-6 text-right'>";
                                peopleHTML += "<small class='stats-label'>Sedang Antri</small>";
                                peopleHTML += "<h4>" + JSONObject[key]['sedang_antri'] + "</h4>";
                                peopleHTML += "</div>";
                                peopleHTML += "</div>";
                                peopleHTML += "</div>";
                                peopleHTML += "</div>";
                                peopleHTML += "</div>";
                                if (i == 0) {
                                    if (JSONObject[key]['sedang_antri'] > 0) {
                                        $("#ant").html(JSONObject[key]['sedang_antri']);
                                        var lkt = JSONObject[key]['nama_loket'];
                                        $("#lkt").html(lkt);
                                    } else {
                                        $("#ant").html("0");
                                        $("#lkt").html("0");
                                    }
                                }
                                i++;
                            }
                        }
                        document.getElementById('loket').innerHTML = peopleHTML;
                    } else if (response.type == "response_call") {
                        if(response.bagian=="PMB"){
                            document.getElementById("sound_bagian").src = "sound/pmb.MP3";                            
                        }else if(response.bagian=="PENGAJARAN"){
                            document.getElementById("sound_bagian").src = "sound/pengajaran.MP3";
                        }else{
                            document.getElementById("sound_bagian").src = "sound/keuangan.MP3";
                        } 
                        document.getElementById("show_bagian").innerHTML = "<b>"+response.bagian+"</b>";
                        $("#ant").html(response.antrian);
                        $("#lkt").html(response.loket);
                        var no_antrian = response.antrian + "";
                        if (no_antrian.length == 1) {
                            play_satuan(no_antrian);
                        } else if (no_antrian.length == 2) {
                            var puluhan = no_antrian.charAt(0);
                            var satuan = no_antrian.charAt(1);
                            play_puluhan(puluhan, satuan);
                        } else if (no_antrian.length == 3) {
                            var ratusan = no_antrian.charAt(0);
                            var puluhan = no_antrian.charAt(1);
                            var satuan = no_antrian.charAt(2);
                            play_ratusan(ratusan, puluhan, satuan);
                        }
                        if (response.loket == "1") {
                            document.getElementById("sound_no_loket").src = "sound/satu.wav";
                        } else if (response.loket == "2") {
                            document.getElementById("sound_no_loket").src = "sound/dua.wav";
                        } else if (response.loket == "3") {
                            document.getElementById("sound_no_loket").src = "sound/tiga.wav";
                        } else if (response.loket == "4") {
                            document.getElementById("sound_no_loket").src = "sound/empat.wav";
                        } else if (response.loket == "5") {
                            document.getElementById("sound_no_loket").src = "sound/lima.wav";
                        } else if (response.loket == "6") {
                            document.getElementById("sound_no_loket").src = "sound/enam.wav";
                        } else if (response.loket == "7") {
                            document.getElementById("sound_no_loket").src = "sound/tujuh.wav";
                        } else if (response.loket == "8") {
                            document.getElementById("sound_no_loket").src = "sound/delapan.wav";
                        } else if (response.loket == "9") {
                            document.getElementById("sound_no_loket").src = "sound/sembilan.wav";
                        } else if (response.loket == "10") {
                            document.getElementById("sound_no_loket").src = "sound/sepuluh.wav";
                        }
                    }
                };
                socket.onclose = function () {
                    $.ajax({
                        url: "disconnect.php"
                    }).done(function (data) { // data what is sent back by the php page
                        $('#content').html(data); // display data
                    });
                };
            }
            catch (ex) {
                alert(ex);
            }
        }
        function request_body() {
            showDate();
            setInterval(showTime, 500);
            var msg = {
                type: "request_monitor"
            };
            socket.send(JSON.stringify(msg));
        }
        function showDate() {
            var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
            var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum&#39;at', 'Sabtu'];
            var date = new Date();
            var day = date.getDate();
            var month = date.getMonth();
            var thisDay = date.getDay(),
                    thisDay = myDays[thisDay];
            var yy = date.getYear();
            var year = (yy < 1000) ? yy + 1900 : yy;
            var hari_ini = thisDay + ', ' + day + ' ' + months[month] + ' ' + year;
            $("#date").html(hari_ini);
        }



        function showTime() {
            var a_p = "";
            var today = new Date();
            var curr_hour = today.getHours();
            var curr_minute = today.getMinutes();
            var curr_second = today.getSeconds();
            //menampilkan 12 Jam
            /*
             if (curr_hour < 12) {
             a_p = "AM";
             } else {
             a_p = "PM";
             }
             if (curr_hour == 0) {
             curr_hour = 12;
             }
             if (curr_hour > 12) {
             curr_hour = curr_hour - 12;
             }
             */
            curr_hour = checkTime(curr_hour);
            curr_minute = checkTime(curr_minute);
            curr_second = checkTime(curr_second);
            document.getElementById('time').innerHTML = curr_hour + ":" + curr_minute + ":" + curr_second; //+ " " + a_p
        }
        function checkTime(i) {
            if (i < 10) {
                i = "0" + i;
            }
            return i;
        }
    </script>
    <script>
        function play_satuan(satuan) {
            document.getElementById("sound_bagian").play();
            $("#sound_bagian").on('ended', function () {
                document.getElementById("sound_play").play();
                $("#sound_play").on('ended', function () {
                    apply_sound(satuan);
                    document.getElementById("sound_antrian").play();
                    $("#sound_antrian").on('ended', function () {
                        document.getElementById("sound_loket").play();
                        $("#sound_loket").on('ended', function () {
                            document.getElementById("sound_no_loket").play();
                        });
                    });
                });
            });
        }
        function play_puluhan(puluhan, satuan) {
            document.getElementById("sound_play").play();
            $("#sound_play").on('ended', function () {
                apply_sound(Number(satuan));
                apply_sound_puluhan(Number(puluhan));
                if (Number(puluhan) == 1) {
                    if (Number(satuan) == 0) {
                        document.getElementById("sound_antrian").src = "sound/sepuluh.wav";
                        document.getElementById("sound_antrian").play();
                        $("#sound_antrian").on('ended', function () {
                            document.getElementById("sound_loket").play();
                            $("#sound_loket").on('ended', function () {
                                document.getElementById("sound_no_loket").play();
                                $("#sound_no_loket").on('ended', function () {
                                    location.reload();
                                });
                            });
                        });
                    } else if (Number(satuan) == 1) {
                        document.getElementById("sound_antrian").src = "sound/sebelas.wav";
                        document.getElementById("sound_antrian").play();
                        $("#sound_antrian").on('ended', function () {
                            document.getElementById("sound_loket").play();
                            $("#sound_loket").on('ended', function () {
                                document.getElementById("sound_no_loket").play();
                                $("#sound_no_loket").on('ended', function () {
                                    location.reload();
                                });
                            });
                        });
                    } else {
                        document.getElementById("sound_antrian").play();
                        $("#sound_antrian").on('ended', function () {
                            document.getElementById("sound_status").src = "sound/belas.wav";
                            document.getElementById("sound_status").play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_loket").play();
                                $("#sound_loket").on('ended', function () {
                                    document.getElementById("sound_no_loket").play();
                                    $("#sound_no_loket").on('ended', function () {
                                        location.reload();
                                    });
                                });
                            });
                        });
                    }
                } else {
                    if (Number(satuan) == 0) {
                        document.getElementById("sound_puluhan").play();
                        $("#sound_puluhan").on('ended', function () {
                            document.getElementById("sound_status").src = "sound/puluh.wav";
                            document.getElementById("sound_status").play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_loket").play();
                                $("#sound_loket").on('ended', function () {
                                    document.getElementById("sound_no_loket").play();
                                    $("#sound_no_loket").on('ended', function () {
                                        location.reload();
                                    });
                                });
                            });
                        });
                    } else {
                        document.getElementById("sound_puluhan").play();
                        $("#sound_puluhan").on('ended', function () {
                            document.getElementById("sound_status").src = "sound/puluh.wav";
                            document.getElementById("sound_status").play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_antrian").play();
                                $("#sound_antrian").on('ended', function () {
                                    document.getElementById("sound_loket").play();
                                    $("#sound_loket").on('ended', function () {
                                        document.getElementById("sound_no_loket").play();
                                        $("#sound_no_loket").on('ended', function () {
                                            location.reload();
                                        });
                                    });
                                });
                            });
                        });
                    }
                }
            });
        }
        function play_ratusan(ratusan, puluhan, satuan) {
            document.getElementById("sound_play").play();
            $("#sound_play").on('ended', function () {
                apply_sound(satuan);
                apply_sound_puluhan(puluhan);
                apply_sound_ratusan(ratusan);
                if (Number(ratusan) == 1) {
                    if (Number(puluhan) == 0) {
                        if (Number(satuan) == 0) {
                            document.getElementById('sound_status').src = "sound/seratus.wav";
                            document.getElementById('sound_status').play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_loket").play();
                                $("#sound_loket").on('ended', function () {
                                    document.getElementById("sound_no_loket").play();
                                    $("#sound_no_loket").on('ended', function () {
                                        location.reload();
                                    });
                                });
                            });
                        } else {
                            document.getElementById('sound_status').src = "sound/seratus.wav";
                            document.getElementById('sound_status').play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_antrian").play();
                                $("#sound_antrian").on('ended', function () {
                                    document.getElementById("sound_loket").play();
                                    $("#sound_loket").on('ended', function () {
                                        document.getElementById("sound_no_loket").play();
                                        $("#sound_no_loket").on('ended', function () {
                                            location.reload();
                                        });
                                    });
                                });
                            });
                        }
                    } else if (Number(puluhan) == 1) {
                        if (Number(satuan) == 0) {
                            document.getElementById('sound_status').src = "sound/seratus.wav";
                            document.getElementById('sound_status').play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_puluhan").src = "sound/sepuluh.wav";
                                document.getElementById("sound_puluhan").play();
                                $("#sound_puluhan").on('ended', function () {
                                    document.getElementById("sound_loket").play();
                                    $("#sound_loket").on('ended', function () {
                                        document.getElementById("sound_no_loket").play();
                                        $("#sound_no_loket").on('ended', function () {
                                            location.reload();
                                        });
                                    });
                                });
                            });
                        } else if (Number(satuan) == 1) {
                            document.getElementById('sound_status').src = "sound/seratus.wav";
                            document.getElementById('sound_status').play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_puluhan").src = "sound/sebelas.wav";
                                document.getElementById("sound_puluhan").play();
                                $("#sound_puluhan").on('ended', function () {
                                    document.getElementById("sound_loket").play();
                                    $("#sound_loket").on('ended', function () {
                                        document.getElementById("sound_no_loket").play();
                                        $("#sound_no_loket").on('ended', function () {
                                            location.reload();
                                        });
                                    });
                                });
                            });
                        } else {
                            document.getElementById('sound_status').src = "sound/seratus.wav";
                            document.getElementById('sound_status').play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_antrian").play();
                                $("#sound_antrian").on('ended', function () {
                                    document.getElementById("sound_belasan").play();
                                    $("#sound_belasan").on('ended', function () {
                                        document.getElementById("sound_loket").play();
                                        $("#sound_loket").on('ended', function () {
                                            document.getElementById("sound_no_loket").play();
                                            $("#sound_no_loket").on('ended', function () {
                                                location.reload();
                                            });
                                        });
                                    });
                                });
                            });
                        }
                    } else {
                        document.getElementById('sound_ratusan').src = "sound/seratus.wav";
                        document.getElementById('sound_ratusan').play();
                        $("#sound_ratusan").on('ended', function () {
                            document.getElementById("sound_puluhan").play();
                            $("#sound_puluhan").on('ended', function () {
                                document.getElementById("sound_status").src = "sound/puluh.wav";
                                document.getElementById("sound_status").play();
                                $("#sound_status").on('ended', function () {
                                    if (Number(satuan) == 0) {
                                        document.getElementById("sound_loket").play();
                                        $("#sound_loket").on('ended', function () {
                                            document.getElementById("sound_no_loket").play();
                                            $("#sound_no_loket").on('ended', function () {
                                                location.reload();
                                            });
                                        });
                                    } else {
                                        document.getElementById("sound_antrian").play();
                                        $("#sound_antrian").on('ended', function () {
                                            document.getElementById("sound_loket").play();
                                            $("#sound_loket").on('ended', function () {
                                                document.getElementById("sound_no_loket").play();
                                                $("#sound_no_loket").on('ended', function () {
                                                    location.reload();
                                                });
                                            });
                                        });
                                    }
                                });
                            });
                        });
                    }
                } else {
                    if (Number(puluhan) == 0) {
                        if (Number(satuan) == 0) {
                            document.getElementById("sound_ratusan").play();
                            $("#sound_ratusan").on('ended', function () {
                                document.getElementById('sound_status').src = "sound/ratus.wav";
                                document.getElementById('sound_status').play();
                                $("#sound_status").on('ended', function () {
                                    document.getElementById("sound_loket").play();
                                    $("#sound_loket").on('ended', function () {
                                        document.getElementById("sound_no_loket").play();
                                        $("#sound_no_loket").on('ended', function () {
                                            location.reload();
                                        });
                                    });
                                });
                            });
                        } else {
                            document.getElementById("sound_ratusan").play();
                            $("#sound_ratusan").on('ended', function () {
                                document.getElementById('sound_status').src = "sound/ratus.wav";
                                document.getElementById('sound_status').play();
                                $("#sound_status").on('ended', function () {
                                    document.getElementById("sound_antrian").play();
                                    $("#sound_antrian").on('ended', function () {
                                        document.getElementById("sound_loket").play();
                                        $("#sound_loket").on('ended', function () {
                                            document.getElementById("sound_no_loket").play();
                                            $("#sound_no_loket").on('ended', function () {
                                                location.reload();
                                            });
                                        });
                                    });
                                });
                            });
                        }
                    } else if (Number(puluhan) == 1) {
                        if (Number(satuan) == 0) {
                            document.getElementById("sound_ratusan").play();
                            $("#sound_ratusan").on('ended', function () {
                                document.getElementById('sound_status').src = "sound/ratus.wav";
                                document.getElementById('sound_status').play();
                                $("#sound_status").on('ended', function () {
                                    document.getElementById("sound_puluhan").src = "sound/sepuluh.wav";
                                    document.getElementById("sound_puluhan").play();
                                    $("#sound_puluhan").on('ended', function () {
                                        document.getElementById("sound_loket").play();
                                        $("#sound_loket").on('ended', function () {
                                            document.getElementById("sound_no_loket").play();
                                            $("#sound_no_loket").on('ended', function () {
                                                location.reload();
                                            });
                                        });
                                    });
                                });
                            });
                        } else if (Number(satuan) == 1) {
                            document.getElementById("sound_ratusan").play();
                            $("#sound_ratusan").on('ended', function () {
                                document.getElementById('sound_status').src = "sound/ratus.wav";
                                document.getElementById('sound_status').play();
                                $("#sound_status").on('ended', function () {
                                    document.getElementById("sound_puluhan").src = "sound/sebelas.wav";
                                    document.getElementById("sound_puluhan").play();
                                    $("#sound_puluhan").on('ended', function () {
                                        document.getElementById("sound_loket").play();
                                        $("#sound_loket").on('ended', function () {
                                            document.getElementById("sound_no_loket").play();
                                            $("#sound_no_loket").on('ended', function () {
                                                location.reload();
                                            });
                                        });
                                    });
                                });
                            });
                        } else {
                            document.getElementById("sound_ratusan").play();
                            $("#sound_ratusan").on('ended', function () {
                                document.getElementById('sound_status').src = "sound/ratus.wav";
                                document.getElementById('sound_status').play();
                                $("#sound_status").on('ended', function () {
                                    document.getElementById("sound_antrian").play();
                                    $("#sound_antrian").on('ended', function () {
                                        document.getElementById("sound_puluhan").src = "sound/belas.wav";
                                        document.getElementById("sound_puluhan").play();
                                        $("#sound_puluhan").on('ended', function () {
                                            document.getElementById("sound_loket").play();
                                            $("#sound_loket").on('ended', function () {
                                                document.getElementById("sound_no_loket").play();
                                                $("#sound_no_loket").on('ended', function () {
                                                    location.reload();
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        }
                    } else {
                        document.getElementById("sound_ratusan").play();
                        $("#sound_ratusan").on('ended', function () {
                            document.getElementById('sound_status').src = "sound/ratus.wav";
                            document.getElementById('sound_status').play();
                            $("#sound_status").on('ended', function () {
                                document.getElementById("sound_puluhan").play();
                                $("#sound_puluhan").on('ended', function () {
                                    if (Number(satuan) == 0) {
                                        document.getElementById("sound_belasan").src = "sound/puluh.wav";
                                        document.getElementById("sound_belasan").play();
                                        $("#sound_belasan").on('ended', function () {
                                            document.getElementById("sound_loket").play();
                                            $("#sound_loket").on('ended', function () {
                                                document.getElementById("sound_no_loket").play();
                                                $("#sound_no_loket").on('ended', function () {
                                                    location.reload();
                                                });
                                            });
                                        });
                                    } else {
                                        document.getElementById("sound_belasan").src = "sound/puluh.wav";
                                        document.getElementById("sound_belasan").play();
                                        $("#sound_belasan").on('ended', function () {
                                            document.getElementById('sound_antrian').play();
                                            $("#sound_antrian").on('ended', function () {
                                                document.getElementById("sound_loket").play();
                                                $("#sound_loket").on('ended', function () {
                                                    document.getElementById("sound_no_loket").play();
                                                    $("#sound_no_loket").on('ended', function () {
                                                        location.reload();
                                                    });
                                                });
                                            });
                                        });
                                    }
                                });
                            });
                        });
                    }
                }
            });
        }
        function set_sound(src) {
            document.getElementById("sound_antrian").src = "sound/" + src + ".wav";
        }
        function set_sound_puluhan(src) {
            document.getElementById("sound_puluhan").src = "sound/" + src + ".wav";
        }
        function set_sound_ratusan(src) {
            document.getElementById("sound_ratusan").src = "sound/" + src + ".wav";
        }
        function apply_sound(satuan) {
            if (Number(satuan) == 0) {
                set_sound("sepuluh");
            } else if (Number(satuan) == 1) {
                set_sound("satu");
            } else if (Number(satuan) == 2) {
                set_sound("dua");
            } else if (Number(satuan) == 3) {
                set_sound("tiga");
            } else if (Number(satuan) == 4) {
                set_sound("empat");
            } else if (Number(satuan) == 5) {
                set_sound("lima");
            } else if (Number(satuan) == 6) {
                set_sound("enam");
            } else if (Number(satuan) == 7) {
                set_sound("tujuh");
            } else if (Number(satuan) == 8) {
                set_sound("delapan");
            } else if (Number(satuan) == 9) {
                set_sound("sembilan");
            }
        }
        function apply_sound_puluhan(satuan) {
            if (Number(satuan) == 1) {
                set_sound_puluhan("satu");
            } else if (Number(satuan) == 2) {
                set_sound_puluhan("dua");
            } else if (Number(satuan) == 3) {
                set_sound_puluhan("tiga");
            } else if (Number(satuan) == 4) {
                set_sound_puluhan("empat");
            } else if (Number(satuan) == 5) {
                set_sound_puluhan("lima");
            } else if (Number(satuan) == 6) {
                set_sound_puluhan("enam");
            } else if (Number(satuan) == 7) {
                set_sound_puluhan("tujuh");
            } else if (Number(satuan) == 8) {
                set_sound_puluhan("delapan");
            } else if (Number(satuan) == 9) {
                set_sound_puluhan("sembilan");
            }
        }
        function apply_sound_ratusan(satuan) {
            if (Number(satuan) == 1) {
                set_sound_ratusan("satu");
            } else if (Number(satuan) == 2) {
                set_sound_ratusan("dua");
            } else if (Number(satuan) == 3) {
                set_sound_ratusan("tiga");
            } else if (Number(satuan) == 4) {
                set_sound_ratusan("empat");
            } else if (Number(satuan) == 5) {
                set_sound_ratusan("lima");
            } else if (Number(satuan) == 6) {
                set_sound_ratusan("enam");
            } else if (Number(satuan) == 7) {
                set_sound_ratusan("tujuh");
            } else if (Number(satuan) == 8) {
                set_sound_ratusan("delapan");
            } else if (Number(satuan) == 9) {
                set_sound_ratusan("sembilan");
            }
        }
    </script>
</html>

