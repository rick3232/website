<div class="wrapper wrapper-content">
    <div class="row">
        <div class="col-md-8" id="mahasiswa">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <h1><center><marquee>STMIK AKAKOM YOGYAKARTA</marquee></center></h1>
                </div>
            </div>
        </div>
        <div class="col-md-4" id="mahasiswa">
            <div class="ibox float-e-margins">
                <div class="ibox-content text-center">
                    <label class="control-label" id="time"></label><br>
                    <label class="control-label" id="date"></label>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <span class="pull-left"><b>BAGIAN</b></span>
                    <span class="pull-right" id='show_bagian'></span>
                </div>
                <div class="ibox-content text-center">
                    <div class="row">
                        <div class="col-md-6">
                            <span><b>NO URUT</b></span>
                            <h1 class="font-bold" style="font-size: 240px" id="ant"></h1>
                        </div>
                        <div class="col-md-6">
                            <span><b>LOKET</b></span>
                            <h1 class="font-bold" style="font-size: 240px" id="lkt"></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 text-center">
            <div class="ibox float-e-margins ">
                <div class="ibox-title">
                    <h5 class="">VIDEO </h5>
                </div>
                <div class="ibox-content">
                    <video controls>
                        <source height=200 src="test.mp4" type="video/mp4">
                        Your browser does not support HTML5 video.
                    </video>
                </div>
            </div>
        </div>
    </div>
    <div class="row" id="loket">
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content text-center">
                    <div class="row">
                        <span>Copyright @ 2015</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <audio src="" id="sound_status">
    </audio>
    <audio src="sound/pmb.MP3" id="sound_bagian">
    </audio>    
    <audio src="sound/belas.wav" id="sound_belasan">
    </audio>
    <audio src="sound/puluh.wav" id="sound_puluhan">
    </audio>
    <audio src="sound/puluh.wav" id="sound_ratusan">
    </audio>
    <audio src="sound/0_antrian.wav" id="sound_play">
    </audio>
    <audio src="sound/satu.wav" id="sound_antrian">
    </audio>
    <audio src="sound/kasir.wav" id="sound_loket">
    </audio>
    <audio src="sound/dua.wav" id="sound_no_loket">
    </audio>
</div>