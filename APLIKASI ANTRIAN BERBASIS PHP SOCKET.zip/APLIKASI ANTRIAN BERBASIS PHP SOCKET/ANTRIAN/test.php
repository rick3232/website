<?php

/**
 * Created by PhpStorm.
 * User: Dhandy
 * Date: 6/1/15
 * Time: 8:17 PM
 */
mysql_connect("localhost", "root", "");
mysql_select_db("agus_slamet");
for ($i =1; $i <=2; $i++) {
    $sql1 = "insert into antrian(mahasiswa,loket,status_layanan) values(1,1,'sudah')";
    $sql2 = "insert into antrian(mahasiswa,loket,status_layanan) values(2,1,'sudah')";
    mysql_query($sql1);
    mysql_query($sql2);
}
