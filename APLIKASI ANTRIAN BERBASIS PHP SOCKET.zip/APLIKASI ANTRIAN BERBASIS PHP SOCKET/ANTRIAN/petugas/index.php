<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>APP ANTRIAN</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="../assets/css/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="../assets/css/animate.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg" onload="connect();">
<div id="content"></div>
</body>
<!-- Mainly scripts -->
<script src="../assets/js/jquery-2.1.1.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/plugins/chosen/chosen.jquery.js"></script>
<script>
    var socket;
    var url = null;
    var host= "127.0.0.1";
    var port="12345";
    var path=null;

    function connect()
    {
        host="ws://"+host+":"+port;
        url=host;
        try{
            socket = new WebSocket(host);
            socket.onopen  = function(msg){
                $.ajax({
                    url: "login.php"
                }).done(function(data) { // data what is sent back by the php page
                    $('#content').html(data); // display data
                    request_loket();
                });
            };
            socket.onmessage = function(msg){
                var response = JSON.parse(msg.data);
                if(response.type=='response_login'){
                    cek_login(response);
                }else if(response.type=='response_loket'){
                    var JSONObject = response.response;
                    var peopleHTML = "";
                    for (var key in JSONObject) {
                        if (JSONObject.hasOwnProperty(key)) {
                            peopleHTML += "<option value='"+JSONObject[key]["id_loket"]+"'>";
                            peopleHTML +=  "LOKET "+JSONObject[key]["nama_loket"] +" ("+JSONObject[key]["bagian"]+")</option>";
                        }
                    }
                    document.getElementById('select_loket').innerHTML=peopleHTML;
                    var config = {
                        '.chosen-select'           : {},
                        '.chosen-select-deselect'  : {allow_single_deselect:true},
                        '.chosen-select-no-single' : {disable_search_threshold:10},
                        '.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
                        '.chosen-select-width'     : {width:"95%"}
                    }
                    for (var selector in config) {
                        $(selector).chosen(config[selector]);
                    }
                }else if(response.type=='response_first_antrian'){
                    if(response.first_antrian==response.jumlah_antrian){
                        $("#next_call").hide();
                    }else{
                        $("#next_call").show();
                    }
                    $("#jumlah_antrian").html(response.jumlah_antrian);
                    $("#antrian").val(response.first_antrian);
                    $("#next_antrian").html(response.first_antrian);
                }else if(response.type=='response_next_antrian'){
                    var loket = $("#loket").val();
                    if(loket==response.loket){
                        var antrian = parseInt(document.getElementById("antrian").value)+1;
                        if(response.antrian==antrian){
                            $("#next_call").hide();
                        }else{
                            $("#next_call").show();
                        }
                        document.getElementById('antrian').value=response.antrian;
                        document.getElementById('next_antrian').innerHTML=response.antrian;
                    }
                }
            };
            socket.onclose   = function(msg){
                $.ajax({
                    url: "disconnect.php"
                }).done(function(data) { // data what is sent back by the php page
                    $('#content').html(data); // display data
                });
            };
        }
        catch(ex){
            alert(ex);
        }
    }

    function login(){
        var msg = {
            type:"request_login",
            by:"petugas",
            loket:document.getElementById('select_loket').value,
            username:$("#username").val(),
            password:$("#password").val()
        };
        socket.send(JSON.stringify(msg));
        return false;
    }
    function cek_login(response){
        if(response.response=='true'){
            alert("LOGIN BERHASIL");
            $.ajax({
                url: "main.php"
            }).done(function(data) { // data what is sent back by the php page
                $('#content').html(data); // display data
                $("#id_petugas").val(response.id_petugas);
                $("#loket").val(response.loket);                
                $("#my_loket").text("Loket "+response.nama_loket+" ("+response.bagian+")");
                request_first_antrian();
            });
        }else{
            alert('GAGAL LOGIN BOS');
        }
    }
    function request_loket(){
        var msg = {
            id:"petugas",
            type:"request_loket"
        };
        socket.send(JSON.stringify(msg));
    }
    function request_body(){
        var petugas = $("#id_petugas").val();
        var msg = {
            type:"request_body",
            by:"petugas",
            petugas:petugas
        };
        socket.send(JSON.stringify(msg));
    }
    function request_first_antrian(){
        var loket = $("#loket").val();
        var msg = {
            type:"request_first_antrian",
            loket:loket
        };
        socket.send(JSON.stringify(msg));
    }
    function request_next_antrian(){
        var next = parseInt($("#antrian").val());
        var loket = $("#loket").val();
        var msg = {
            type:"request_next_antrian",
            loket:loket,
            start:next
        };
        socket.send(JSON.stringify(msg));
    }
    function call(){
        var antrian = parseInt($("#antrian").val());
        var loket = $("#loket").val();
        var msg = {
            type:"request_call",
            loket:loket,
            antrian:antrian
        };
        socket.send(JSON.stringify(msg));
    }
</script>
</html>

