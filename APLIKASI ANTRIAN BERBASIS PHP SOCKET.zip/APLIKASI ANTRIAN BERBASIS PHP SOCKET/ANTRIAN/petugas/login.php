<div class="middle-box text-center loginscreen  animated fadeInDown">
    <div>
        <div>

            <h1 class="logo-name">AK</h1>

        </div>
        <h3>SELAMAT DATANG</h3>
        <p>APLIKASI PETUGAS ANTRIAN STMIK AKAKOM YOGYAKARTA
            <!--Continually expanded and constantly improved Inspinia Admin Them (IN+)-->
        </p>
        <p>Silahkan LOGIN</p>
        <form class="m-t" role="form" onsubmit="return login();">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Username" id="username" required="">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" placeholder="Password" id="password" required="">
            </div>
            <div class="form-group">
                <select id="select_loket" data-placeholder="Choose a Country..." class="chosen-select" style="width:300px;" tabindex="2"></select>
            </div>
            <button type="submit" class="btn btn-primary block full-width m-b">Login</button>
        </form>
        <p class="m-t"> <small>PT. ANGOITECH INDONESIA &copy; <?php echo(date('Y'));?></small> </p>
    </div>
</div>
