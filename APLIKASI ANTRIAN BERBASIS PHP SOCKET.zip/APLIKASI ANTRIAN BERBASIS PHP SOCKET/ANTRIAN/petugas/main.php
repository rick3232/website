<div class="wrapper wrapper-content">
    <div class="row">
        <div class="col-md-8">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Antrian</h5>
                    <h5 class="pull-right"><a href="index.php">Logout</a></h5>
                    <input type="hidden" id="id_petugas">
                    <input type="hidden" id="loket">
                </div>
                <div class="ibox-content text-center">

                    <div class="row">
                        <input type="hidden" id="antrian" value="">
                        <h1 class="no-margins">Anda Melayani No Urut <span id="next_antrian"></span></h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Jumlah Antrian</h5>
                    <h5 class="pull-right" id="my_loket">Loket 10</h5>
                </div>
                <div class="ibox-content text-center">
                    <h1 class="no-margins"><span id="jumlah_antrian"></span></h1>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Actions</h5>
                </div>
                <div class="ibox-content">
                    <div class="row">
                        <div class="col-md-10 col-lg-offset-2">
                            <div class="col-md-4">
                                <button class="btn btn-primary dim btn-large-dim" onclick="call()"><i class="fa fa-phone"></i></button>
                            </div>
                            <div class="col-md-4">
                                <button class="btn btn-primary dim btn-large-dim"><i class="fa fa-phone-square"></i></button>
                            </div>
                            <div class="col-md-4" id="next_call">
                                <button class="btn btn-primary dim btn-large-dim" onclick="request_next_antrian();" id="next_call"><i class="fa fa-forward"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>