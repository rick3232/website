<!DOCTYPE html>
<html>
    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>APP ANTRIAN</title>
        <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet">
        <link href="../assets/css/plugins/chosen/chosen.css" rel="stylesheet">
        <link href="../assets/css/animate.css" rel="stylesheet">
        <link href="../assets/css/style.css" rel="stylesheet">

    </head>

    <body class="gray-bg" onload="connect()">
        <div id="content"></div>
    </body>
    <!-- Mainly scripts -->
    <script src="../assets/js/jquery-2.1.1.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/plugins/chosen/chosen.jquery.js"></script>
    <script type="text/javascript">
        var socket;
        var url = null;
        var host = "127.0.0.1";
        var port = "12345";
        var path = null;
        function connect()
        {
            host = "ws://" + host + ":" + port;
            url = host;
            try {
                socket = new WebSocket(host);
                socket.onopen = function (msg) {
                    $.ajax({
                        url: "login.php"
                    }).done(function (data) { // data what is sent back by the php page
                        $('#content').html(data); // display data
                    });
                };
                socket.onmessage = function (msg) {
                    var response = JSON.parse(msg.data);
                    if (response.type == 'response_login') {
                        cek_login(response);
                    } else if (response.type == 'response_no_antrian') {
                        request_body();
                    } else if (response.type == 'response_body') {
                        var JSONObject = response.loket;
                        var JSONObject_1 = response.detail_loket;
                        if (response.no_antrian == null || response.no_antrian == "") {
                            var html = "<h4 class='no-margins'>Anda Belum Mengambil No Antrian</h4>";
                            document.getElementById('no_antrian').innerHTML = html;
                            var peopleHTML1 = "<option>Pilih Loket</option>";
                            for (var key in JSONObject) {
                                if (JSONObject.hasOwnProperty(key)) {
                                    peopleHTML1 += "<option value='" + JSONObject[key]["id_loket"] + "'>";
                                    peopleHTML1 += JSONObject[key]["nama_loket"] +"("+JSONObject[key]["bagian"]+")</option>";
                                }
                            }
                            document.getElementById('select_loket').innerHTML = "";
                            document.getElementById('select_loket').innerHTML = peopleHTML1;
                            $("#no_loket_id").hide();
                            $("#ambil_antrian").show();
                            $("#cetak_loket_id").hide();
                            var config = {
                                '.chosen-select': {},
                                '.chosen-select-deselect': {allow_single_deselect: true},
                                '.chosen-select-no-single': {disable_search_threshold: 10},
                                '.chosen-select-no-results': {no_results_text: 'Oops, nothing found!'},
                                '.chosen-select-width': {width: "95%"}
                            }
                            for (var selector in config) {
                                $(selector).chosen(config[selector]);
                            }
                        } else {
                            var html = "<h1 class='no-margins'>" + response.no_antrian + "</h1>";
                            document.getElementById('no_antrian').innerHTML = html;
                            document.getElementById('bagian').innerHTML = response.bagian;
                            $("#ambil_antrian").hide();
                            document.getElementById('mahasiswa').className = 'col-md-6';
                            document.getElementById("no_loket").innerHTML = "<h1 class='no-margins'>Loket " + response.no_loket + "</h1>";
                            $("#no_loket_id").show();
                            $("#cetak_loket_id").show();
                        }
                        var peopleHTML = "";
                        for (var key in JSONObject_1) {
                            if (JSONObject_1.hasOwnProperty(key)) {
                                peopleHTML += "<div class='col-md-2'>";
                                peopleHTML += "<div class='ibox float-e-margins'>";
                                peopleHTML += "<div class='ibox-title'>";
                                peopleHTML += "<h5 class='pull-left'>Loket " + JSONObject_1[key]['nama_loket'] + "</h5>";
                                peopleHTML += "<h5 class='pull-right'>" + JSONObject_1[key]['bagian'] + "</h5>";
                                peopleHTML += "</div>";
                                peopleHTML += "<div class='ibox-content'>";
                                peopleHTML += "<div class='row'>";
                                peopleHTML += "<div class='col-xs-6'>";
                                peopleHTML += "<small class='stats-label'>Jumlah Antrian</small>";
                                peopleHTML += "<h4>" + JSONObject_1[key]['jumlah_antrian'] + "</h4>";
                                peopleHTML += "</div>";
                                peopleHTML += "<div class='col-xs-6 text-right'>";
                                peopleHTML += "<small class='stats-label'>Sedang Antri</small>";
                                peopleHTML += "<h4>" + JSONObject_1[key]['sedang_antri'] + "</h4>";
                                peopleHTML += "</div>";
                                peopleHTML += "</div>";
                                peopleHTML += "</div>";
                                peopleHTML += "</div>";
                                peopleHTML += "</div>";
                            }
                        }
                        document.getElementById('loket').innerHTML = peopleHTML;
                    } else if (response.type == "refresh_loket") {
                        request_body();
                    } else if(response.type=="response_cetak"){
                        if(response.status=="OK"){
                            document.getElementById("btn_cetak").innerHTML="Print OK";
                        }else{
                            alert("DATA GAGAL DI CETAK! Silahkan Cetak Lagi");
                        }
                    }
                };
                socket.onclose = function () {
                    $.ajax({
                        url: "disconnect.php"
                    }).done(function (data) { // data what is sent back by the php page
                        $('#content').html(data); // display data
                    });
                };
            }
            catch (ex) {
                alert(ex);
            }
        }

        function login() {
            var msg = {
                type: "request_login",
                by: "mahasiswa",
                username: $("#username").val(),
                password: $("#password").val()
            };
            socket.send(JSON.stringify(msg));
            return false;
        }
        function cek_login(response) {
            if (response.response == 'true') {
                $.ajax({
                    url: "main.php"
                }).done(function (data) { // data what is sent back by the php page
                    $('#content').html(data); // display data
                    $("#id_mahasiswa").val(response.id_mahasiswa);
                    $("#nama_mahasiswa").html(response.nama_mahasiswa);
                    request_body();
                });
            } else {
                alert('GAGAL LOGIN BOS');
            }
        }
        function request_body() {
            var mahasiswa = $("#id_mahasiswa").val();
            var msg = {
                type: "request_body",
                by: "mahasiswa",
                mahasiswa: mahasiswa
            };
            socket.send(JSON.stringify(msg));
        }
        function pilihLoket(val) {
            var mahasiswa = $("#id_mahasiswa").val();
            var msg = {
                type: "request_no_antrian",
                by: "mahasiswa",
                mahasiswa: mahasiswa,
                loket: val
            };
            socket.send(JSON.stringify(msg));
        }
        function cetak() {
            var no_antrian = $("#no_antrian h1").html();
            var loket = $("#no_loket h1").html();
            var msg = {
                type: "request_cetak",
                no_antrian: no_antrian,
                loket: loket
            };
            socket.send(JSON.stringify(msg));
        }
    </script>
</html>

