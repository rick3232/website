<div class="middle-box text-center animated fadeInDown">
    <h1>LOST</h1>
    <h3 class="font-bold">CONNECTION</h3>

    <div class="error-desc">
       Tidak dapat terhubung ke server. Coba Lagi.<br>
       Tekan Tombol Berikut Untuk Melanjutkan
       <br/><button onclick="location.reload();" class="btn btn-primary m-t">Re Connect</button>
    </div>
</div>
