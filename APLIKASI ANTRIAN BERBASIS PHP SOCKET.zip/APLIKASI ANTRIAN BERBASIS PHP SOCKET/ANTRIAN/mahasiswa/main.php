<div class="wrapper wrapper-content">
    <div class="row">
        <div class="col-md-6" id="mahasiswa">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>MAHASISWA</h5>
                    <h5 class="pull-right"><a href="index.php">Logout</a></h5>
                </div>
                <div class="ibox-content text-center">

                    <div class="row">
                        <h1 class="no-margins">Hello, <span id="nama_mahasiswa"></span><input type="hidden" id="id_mahasiswa"> </h1>
                    </div>


                </div>
            </div>
        </div>
        <div class="col-md-2" id="ambil_antrian">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Ambil Antrian</h5>
                </div>
                <div class="ibox-content text-center">
                    <select id="select_loket" data-placeholder="Pilih Loket..." class="chosen-select" style="width:150px;" tabindex="2" onchange="pilihLoket(this.value);">
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-2">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>No Antrian</h5>
                </div>
                <div class="ibox-content text-center">
                    <div id="no_antrian">

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2" id="no_loket_id">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5 class='pull-left'>Bagian</h5>
                    <h5 class='pull-right' id='bagian'></h5>
                </div>
                <div class="ibox-content text-center">
                    <div id="no_loket">

                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2" id="cetak_loket_id">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Cetak Antrian</h5>
                </div>
                <div class="ibox-content text-center">
                    <h1 class="no-margins" id="btn_cetak"><button class="btn btn-primary" onclick="cetak();"><i class="fa fa-print"></i></button></h1>
                </div>
            </div>
        </div>
    </div>
    <div class="row" id="loket">
    </div>
</div>